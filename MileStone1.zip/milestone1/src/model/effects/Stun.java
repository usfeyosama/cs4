package model.effects;

public class Stun extends Effect {
	private EffectType type ;
	public Stun(){
	super();
	type =EffectType.DEBUFF;
	}
}