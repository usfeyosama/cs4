package model.effects;

public class Silence extends Effect {
	private EffectType type ;
	public Silence(){
	super();
	type =EffectType.DEBUFF;
	
	}
}
