package model.effects;

public class Shield extends Effect{
	private EffectType type ;
	public Shield(){
	super();
	type =EffectType.BUFF;
	
	}
}
