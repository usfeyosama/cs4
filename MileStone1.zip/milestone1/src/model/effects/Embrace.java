package model.effects;

public class Embrace extends Effect {
	private EffectType type ;
	public Embrace(){
	super();
	type =EffectType.BUFF;
	
	}
}
