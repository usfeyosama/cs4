package model.effects;

public class SpeedUp extends Effect {
	private EffectType type ;
	public SpeedUp(){
	super();
	type =EffectType.BUFF;
	
	}
}
