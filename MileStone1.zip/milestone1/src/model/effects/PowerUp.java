package model.effects;

public class PowerUp extends Effect{
	private EffectType type ;
	public PowerUp(){
	super();
	type =EffectType.BUFF;
	
	}
}
