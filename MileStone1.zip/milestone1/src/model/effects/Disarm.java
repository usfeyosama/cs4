package model.effects;

public class Disarm extends Effect {
	private EffectType type ;
	public Disarm(){
	super();
	type =EffectType.DEBUFF;
	
	}
}

