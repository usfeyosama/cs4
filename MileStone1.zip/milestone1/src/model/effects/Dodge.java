package model.effects;

public class Dodge extends Effect {
	private EffectType type ;
	public Dodge(){
	super();
	type =EffectType.BUFF;
	
	}
}

