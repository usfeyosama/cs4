package model.effects;

public class Effect {
	private String name;
	public int duration;
	private EffectType type;
	public Effect(){
		this.name="";
		this.duration=0;
		this.type=null;
		
	}
	public Effect(String name, int duration, EffectType type){
		this.name=name;
		this.duration=duration;
		this.type=type;
	}
	public String getName(){
		return name;
	}
	public EffectType getType(){
		return type;
	}
	public int getDuration(){
		return duration;
	}
	public void setDuration(int d){
		this.duration=d;
	}
	
}
