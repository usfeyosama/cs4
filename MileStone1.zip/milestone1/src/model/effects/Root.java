package model.effects;

public class Root extends Effect {
	private EffectType type ;
	public Root(){
	super();
	type =EffectType.DEBUFF;
	
	}
}