package model.effects;

public class Shock extends Effect {
	private EffectType type ;
	public Shock(){
	super();
	type =EffectType.DEBUFF;
	
	}
}