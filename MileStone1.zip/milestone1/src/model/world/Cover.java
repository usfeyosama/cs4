package model.world;
import java.util.*;
import java.awt.Point;

public class Cover {
	private int currentHP;
	private Point location;
	
	public Cover(){
		currentHP=0;
		int Point=0;
	}
	 
	
		
		
	

}
