package model.abilities;

import model.effects.Effect;

public class CrowdControlAbility extends Ability{
	Effect effect;
	public CrowdControlAbility(){
		super();
		effect= null;
	}
	public Effect getEffect(){
		return effect;
	}
}
