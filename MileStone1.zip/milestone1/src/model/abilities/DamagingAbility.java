package model.abilities;

public class DamagingAbility extends Ability{
	private int damageAmount;
	public DamagingAbility(){
		super();
		damageAmount=0;
	}
	public int getDamagingAbility(){
		return damageAmount;
	}
	public void setDamagingAbility(int c){
		damageAmount=c;
	}
	public DamagingAbility(int damageAmount){
		this.damageAmount=damageAmount;
	}
	
}
