package model.abilities;

public class HealingAbility extends Ability{
	private int healAmount;
	public HealingAbility(){
		super();
		healAmount=0;
	}
	public int getHealingAbility(){
		return healAmount;
	}
	public void setHealingAbility(int h){
		healAmount=h;
	}
	public HealingAbility(int healAmount){
		this.healAmount=healAmount;
	}
}
